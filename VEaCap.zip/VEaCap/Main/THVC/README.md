
In the evaluation, we referenced the method in "Thinking Hallucination for Video Captioning". Please download the code to this directory. Sincerely thank them for their contributions!

# Thinking Hallucination for Video Captioning (THVC)

Official PyTorch implementation for the paper: "Thinking Hallucination for video captioning" accepted at ACCV 2022.

👉 You can find the camera-ready paper [here](https://openaccess.thecvf.com/content/ACCV2022/papers/Ullah_Thinking_Hallucination_for_Video_Captioning_ACCV_2022_paper.pdf)
